from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import random

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For demo, allow all
    allow_methods=["*"],
    allow_headers=["*"],
)

class OddsRequest(BaseModel):
    sport: str
    match_id: int
    bookmaker_odds: float

class PredictionResponse(BaseModel):
    match_id: int
    predicted_win_prob: float
    bookmaker_odds: float
    expected_value: float
    value_bet: bool

@app.post("/predict", response_model=PredictionResponse)
async def predict_value_bet(odds_request: OddsRequest):
    # Mock ML prediction: Random probability near bookmaker odds for demo
    predicted_prob = max(0.05, min(0.95, random.gauss(1 / odds_request.bookmaker_odds, 0.1)))

    ev = (predicted_prob * odds_request.bookmaker_odds) - 1
    is_value_bet = ev > 0

    return PredictionResponse(
        match_id=odds_request.match_id,
        predicted_win_prob=round(predicted_prob, 3),
        bookmaker_odds=odds_request.bookmaker_odds,
        expected_value=round(ev, 3),
        value_bet=is_value_bet
    )

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 