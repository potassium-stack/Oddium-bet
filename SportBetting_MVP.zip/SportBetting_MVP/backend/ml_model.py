import random
import numpy as np

class SportsBettingModel:
    """
    Mock ML model for sports betting predictions
    In a real implementation, this would be a trained model using XGBoost, sklearn, etc.
    """
    
    def __init__(self):
        # In a real model, we would load weights, hyperparameters, etc.
        self.feature_importance = {
            "team_history": 0.35,
            "head_to_head": 0.25,
            "current_form": 0.20,
            "home_advantage": 0.15,
            "weather_conditions": 0.05
        }
    
    def predict_win_probability(self, sport, bookmaker_odds):
        """
        Predict the probability of winning for a given bet
        For MVP, we're just simulating probabilities near the implied odds
        
        Args:
            sport: The sport type (football, basketball, etc.)
            bookmaker_odds: The odds provided by the bookmaker
            
        Returns:
            float: Predicted probability of winning
        """
        # Implied probability from bookmaker odds
        implied_prob = 1.0 / bookmaker_odds
        
        # Add noise based on sport (more predictable sports have less noise)
        noise_level = {
            "Football": 0.08,
            "Basketball": 0.06,
            "Tennis": 0.05,
            "Baseball": 0.09,
            "Hockey": 0.07
        }.get(sport, 0.1)  # Default noise for unknown sports
        
        # Generate a prediction with some noise around the implied probability
        # This simulates our model finding slight edges against the bookmaker
        predicted_prob = np.clip(
            random.gauss(implied_prob, noise_level),
            0.05,  # Min probability
            0.95   # Max probability
        )
        
        return predicted_prob
    
    def calculate_expected_value(self, win_probability, bookmaker_odds):
        """
        Calculate the Expected Value of a bet
        
        Args:
            win_probability: Our predicted probability of winning
            bookmaker_odds: The odds provided by the bookmaker
            
        Returns:
            float: The expected value (EV) of the bet
        """
        return (win_probability * bookmaker_odds) - 1
    
    def is_value_bet(self, expected_value, threshold=0.0):
        """
        Determine if a bet has positive expected value
        
        Args:
            expected_value: The calculated EV
            threshold: Minimum EV to consider a value bet (default 0.0)
            
        Returns:
            bool: True if this is a value bet, False otherwise
        """
        return expected_value > threshold 