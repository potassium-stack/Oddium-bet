import React, { useState } from 'react';

const MyBets = () => {
  // Mock bet history data - in a real app, this would come from API
  const [bets] = useState([
    {
      id: 1,
      match: "Liverpool vs Man City",
      sport: "Football",
      odds: 2.15,
      stake: 100,
      placed_at: "2023-10-15T14:30:00",
      status: "won",
      return: 215,
      profit: 115
    },
    {
      id: 2,
      match: "Lakers vs Bulls",
      sport: "Basketball",
      odds: 1.85,
      stake: 50,
      placed_at: "2023-10-14T20:00:00",
      status: "lost",
      return: 0,
      profit: -50
    },
    {
      id: 3,
      match: "Nadal vs Djokovic",
      sport: "Tennis",
      odds: 3.20,
      stake: 75,
      placed_at: "2023-10-13T16:45:00",
      status: "won",
      return: 240,
      profit: 165
    },
    {
      id: 4,
      match: "McGregor vs Poirier",
      sport: "MMA",
      odds: 2.50,
      stake: 60,
      placed_at: "2023-10-12T22:00:00",
      status: "pending",
      return: null,
      profit: null
    },
    {
      id: 5,
      match: "Barcelona vs Real Madrid",
      sport: "Football",
      odds: 1.90,
      stake: 120,
      placed_at: "2023-10-11T19:30:00",
      status: "lost",
      return: 0,
      profit: -120
    }
  ]);

  // Calculate summary stats
  const totalBets = bets.length;
  const completedBets = bets.filter(bet => bet.status !== "pending").length;
  const wonBets = bets.filter(bet => bet.status === "won").length;
  const winRate = completedBets ? (wonBets / completedBets) * 100 : 0;
  const totalProfit = bets.reduce((sum, bet) => sum + (bet.profit || 0), 0);
  const totalStaked = bets.reduce((sum, bet) => sum + bet.stake, 0);
  const roi = totalStaked ? (totalProfit / totalStaked) * 100 : 0;

  // Status badge color mapping
  const statusColors = {
    won: "bg-green-100 text-green-800",
    lost: "bg-red-100 text-red-800",
    pending: "bg-yellow-100 text-yellow-800"
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">My Bets</h2>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-blue-50 rounded-lg p-4 shadow-sm">
          <div className="text-sm text-blue-500 uppercase font-medium mb-1">Win Rate</div>
          <div className="text-2xl font-bold text-blue-800">{winRate.toFixed(1)}%</div>
          <div className="text-xs text-blue-400 mt-1">{wonBets} of {completedBets} bets</div>
        </div>
        
        <div className={`${totalProfit >= 0 ? 'bg-green-50' : 'bg-red-50'} rounded-lg p-4 shadow-sm`}>
          <div className={`text-sm ${totalProfit >= 0 ? 'text-green-500' : 'text-red-500'} uppercase font-medium mb-1`}>Total Profit</div>
          <div className={`text-2xl font-bold ${totalProfit >= 0 ? 'text-green-800' : 'text-red-800'}`}>
            {totalProfit >= 0 ? '+' : ''}{totalProfit.toFixed(2)}
          </div>
          <div className={`text-xs ${totalProfit >= 0 ? 'text-green-400' : 'text-red-400'} mt-1`}>
            ROI: {roi >= 0 ? '+' : ''}{roi.toFixed(2)}%
          </div>
        </div>
        
        <div className="bg-gray-50 rounded-lg p-4 shadow-sm">
          <div className="text-sm text-gray-500 uppercase font-medium mb-1">Active Bets</div>
          <div className="text-2xl font-bold text-gray-800">{bets.filter(bet => bet.status === "pending").length}</div>
          <div className="text-xs text-gray-400 mt-1">Total Stake: {bets.filter(bet => bet.status === "pending").reduce((sum, bet) => sum + bet.stake, 0)}</div>
        </div>
        
        <div className="bg-purple-50 rounded-lg p-4 shadow-sm">
          <div className="text-sm text-purple-500 uppercase font-medium mb-1">Total Wagered</div>
          <div className="text-2xl font-bold text-purple-800">{totalStaked.toFixed(2)}</div>
          <div className="text-xs text-purple-400 mt-1">Across {totalBets} bets</div>
        </div>
      </div>
      
      {/* Virtual Bankroll Chart */}
      <div className="mb-8 bg-gray-50 p-4 rounded-lg">
        <h3 className="text-lg font-medium text-gray-800 mb-2">Bankroll Growth</h3>
        <div className="h-48 bg-white rounded border border-gray-200 flex items-center justify-center">
          <p className="text-gray-500">Bankroll growth chart would appear here</p>
        </div>
      </div>
      
      {/* Bet History Table */}
      <h3 className="text-lg font-medium text-gray-800 mb-4">Bet History</h3>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Match
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Sport
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Odds
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Stake
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                P/L
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {bets.map((bet) => (
              <tr key={bet.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">
                    {new Date(bet.placed_at).toLocaleDateString()}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">{bet.match}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">{bet.sport}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{bet.odds.toFixed(2)}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{bet.stake.toFixed(2)}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColors[bet.status]}`}>
                    {bet.status.charAt(0).toUpperCase() + bet.status.slice(1)}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {bet.status !== "pending" && (
                    <div className={`text-sm font-medium ${bet.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {bet.profit >= 0 ? '+' : ''}{bet.profit?.toFixed(2)}
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MyBets; 