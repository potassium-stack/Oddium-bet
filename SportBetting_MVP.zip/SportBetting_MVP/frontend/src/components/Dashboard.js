import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import BetTable from './BetTable';
import ValueChart from './ValueChart';

const Dashboard = ({ bets }) => {
  const [activeView, setActiveView] = useState('table');
  const [refreshTimer, setRefreshTimer] = useState(30);
  const [liveTicker, setLiveTicker] = useState([]);
  
  // Calculate stats
  const totalBets = bets.length;
  const valueBets = bets.filter(bet => bet.value_bet);
  const valueBetsCount = valueBets.length;
  const valueBetsPercentage = totalBets > 0 ? (valueBetsCount / totalBets) * 100 : 0;
  const avgEV = valueBets.length > 0 
    ? valueBets.reduce((sum, bet) => sum + bet.expected_value, 0) / valueBets.length 
    : 0;
  
  // Simulate live odds ticker
  useEffect(() => {
    // Generate random ticker items
    const sports = ['Football', 'Basketball', 'Tennis', 'Hockey', 'MMA'];
    const teams = [
      ['Liverpool', 'Arsenal'], 
      ['Lakers', 'Celtics'],
      ['Nadal', 'Djokovic'],
      ['Bruins', 'Flyers'],
      ['Jones', 'Cormier']
    ];
    
    const generateTickerItems = () => {
      const newItems = [];
      for (let i = 0; i < 5; i++) {
        const sportIndex = Math.floor(Math.random() * sports.length);
        const teamIndex = sportIndex;
        const odds = (1.5 + Math.random() * 2).toFixed(2);
        const movement = Math.random() > 0.5 ? '↑' : '↓';
        
        newItems.push({
          id: Date.now() + i,
          sport: sports[sportIndex],
          team1: teams[teamIndex][0],
          team2: teams[teamIndex][1],
          odds,
          movement
        });
      }
      return newItems;
    };
    
    setLiveTicker(generateTickerItems());
    
    // Update ticker periodically
    const tickerInterval = setInterval(() => {
      setLiveTicker(generateTickerItems());
    }, 10000);
    
    return () => clearInterval(tickerInterval);
  }, []);
  
  // Refresh countdown timer
  useEffect(() => {
    if (refreshTimer <= 0) {
      // Would refresh data here in a real app
      setRefreshTimer(30);
      return;
    }
    
    const timer = setTimeout(() => {
      setRefreshTimer(refreshTimer - 1);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [refreshTimer]);
  
  // Function to get status badge color
  const getStatusColor = (bet) => {
    if (bet.value_bet) {
      return 'bg-green-100 text-green-800';
    }
    return 'bg-gray-100 text-gray-800';
  };
  
  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-blue-100 text-blue-600">
              <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
              </svg>
            </div>
            <div className="ml-4">
              <h2 className="text-lg font-semibold text-gray-700">Total Bets Analyzed</h2>
              <div className="text-3xl font-bold text-gray-900">{totalBets}</div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-green-100 text-green-600">
              <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
              </svg>
            </div>
            <div className="ml-4">
              <h2 className="text-lg font-semibold text-gray-700">Value Bets Found</h2>
              <div className="flex items-baseline">
                <div className="text-3xl font-bold text-gray-900">{valueBetsCount}</div>
                <div className="ml-2 text-sm text-green-600">({valueBetsPercentage.toFixed(1)}%)</div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-purple-100 text-purple-600">
              <svg className="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
              </svg>
            </div>
            <div className="ml-4">
              <h2 className="text-lg font-semibold text-gray-700">Avg. Expected Value</h2>
              <div className="flex items-baseline">
                <div className="text-3xl font-bold text-gray-900">{(avgEV * 100).toFixed(2)}%</div>
                <div className="ml-2 text-sm text-purple-600">for value bets</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Live Odds Ticker */}
      <div className="bg-gray-800 text-white p-3 rounded-lg shadow-md overflow-hidden">
        <div className="flex items-center space-x-4 animate-marquee">
          <div className="text-yellow-400 font-medium">LIVE ODDS</div>
          {liveTicker.map(item => (
            <div key={item.id} className="flex items-center space-x-2 whitespace-nowrap">
              <span className="text-gray-400">{item.sport}</span>
              <span className="font-medium">{item.team1} vs {item.team2}</span>
              <span className={`font-bold ${item.movement === '↑' ? 'text-green-400' : 'text-red-400'}`}>
                {item.odds} {item.movement}
              </span>
            </div>
          ))}
        </div>
      </div>
      
      {/* Views Toggle & Refresh */}
      <div className="flex justify-between items-center">
        <div className="bg-white rounded-lg shadow p-1 inline-flex">
          <button
            className={`px-4 py-2 text-sm font-medium rounded ${activeView === 'table' ? 'bg-blue-100 text-blue-800' : 'text-gray-500 hover:text-gray-700'}`}
            onClick={() => setActiveView('table')}
          >
            Table View
          </button>
          <button
            className={`px-4 py-2 text-sm font-medium rounded ${activeView === 'chart' ? 'bg-blue-100 text-blue-800' : 'text-gray-500 hover:text-gray-700'}`}
            onClick={() => setActiveView('chart')}
          >
            Chart View
          </button>
        </div>
        
        <div className="flex items-center text-sm text-gray-500">
          <svg className="h-4 w-4 mr-1 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
          </svg>
          Refreshing in {refreshTimer}s
        </div>
      </div>
      
      {/* Main Content - Table View */}
      {activeView === 'table' && (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Match
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Sport
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Bookmaker Odds
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Our Probability
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Expected Value
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Value Bet
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {bets.map((bet) => (
                  <tr key={bet.match_id} className={bet.value_bet ? 'bg-green-50' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{bet.team1} vs {bet.team2}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{bet.sport}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{bet.bookmaker_odds.toFixed(2)}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{(bet.predicted_win_prob * 100).toFixed(1)}%</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`text-sm font-medium ${bet.expected_value >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {(bet.expected_value * 100).toFixed(2)}%
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(bet)}`}>
                        {bet.value_bet ? 'Yes' : 'No'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      {bet.value_bet && (
                        <button className="text-white bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded-md text-sm">
                          Place Bet
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Chart View */}
      {activeView === 'chart' && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="h-80 bg-gray-50 rounded-lg border border-gray-200 flex items-center justify-center">
            <p className="text-gray-500">Bar chart of Expected Value for each bet would appear here</p>
          </div>
        </div>
      )}
      
      {/* "How It Works" Section */}
      <section className="mt-8 bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="text-blue-500 text-xl font-bold mb-2">1. Data Collection</div>
            <p className="text-gray-700">The system continuously collects odds data from major bookmakers and historical sports statistics.</p>
          </div>
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="text-blue-500 text-xl font-bold mb-2">2. AI Prediction</div>
            <p className="text-gray-700">Our ML models analyze the data and predict true probabilities for each outcome, finding discrepancies with bookmaker odds.</p>
          </div>
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="text-blue-500 text-xl font-bold mb-2">3. Value Detection</div>
            <p className="text-gray-700">The system identifies value bets (positive EV) and notifies users in real-time of profitable betting opportunities.</p>
          </div>
        </div>
      </section>
      
      {/* Quick Actions */}
      <div className="bg-blue-50 rounded-lg shadow-md p-6">
        <h3 className="text-lg font-medium text-blue-800 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Link to="/value-bets" className="bg-white p-4 rounded-lg shadow border border-blue-100 hover:border-blue-300 transition-colors">
            <div className="font-medium text-blue-700">View Value Bets</div>
            <div className="text-sm text-gray-500 mt-1">Check all positive EV betting opportunities</div>
          </Link>
          <Link to="/my-bets" className="bg-white p-4 rounded-lg shadow border border-blue-100 hover:border-blue-300 transition-colors">
            <div className="font-medium text-blue-700">My Bet History</div>
            <div className="text-sm text-gray-500 mt-1">Review your past betting performance</div>
          </Link>
          <Link to="/analytics" className="bg-white p-4 rounded-lg shadow border border-blue-100 hover:border-blue-300 transition-colors">
            <div className="font-medium text-blue-700">Performance Analytics</div>
            <div className="text-sm text-gray-500 mt-1">Analyze detailed statistics and trends</div>
          </Link>
          <Link to="/simulation" className="bg-white p-4 rounded-lg shadow border border-blue-100 hover:border-blue-300 transition-colors">
            <div className="font-medium text-blue-700">Run Simulation</div>
            <div className="text-sm text-gray-500 mt-1">Test your betting strategy with historical data</div>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Dashboard; 